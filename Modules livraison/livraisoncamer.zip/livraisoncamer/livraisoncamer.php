<?php

if (!defined('_PS_VERSION_'))
	exit;

class Livraisoncamer extends Module 
{
	
	public function __construct()
	{
		
		$this->name = 'livraisoncamer';
		$this->author = 'Youssouf';
		$this->version = '1.0.0';
		$this->bootstrap = true;
		parent::__construct();
		$this->displayName = $this->l('LivraisonCamer');
		$this->description = $this->l('Avec ce module vos clients pourrons selectionner leurs ville de livraison partout');
		$this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}
	
	public function install()
{
	return (parent::install() && $this->registerHook('displayProductAdditionalInfo') 
	    && $this->registerHook('displayAfterCarrier')
	    && $this->registerHook('Header')
	    );
}

	public function uninstall()
{
    return (parent::uninstall() && $this->registerHook('displayProductAdditionalInfo') 
        && $this->registerHook('displayAfterCarrier')
        && $this->registerHook('Header')
        );
}

public function hookDisplayProductAdditionalInfo()
{
    $this->context->smarty->assign(array(
        'LIVRAISONCAMER_STR' => Configuration::get('LIVRAISONCAMER_STR')
    ));
    
  return $this->display(__FILE__, 'views/templates/hook/productadditionalinfo.tpl');
}

public function hookDisplayAfterCarrier()
{
    $this->context->smarty->assign(array(
        'LIVRAISONCAMER_STR' => Configuration::get('LIVRAISONCAMER_STR')
    ));
    
    return $this->display(__FILE__, 'views/templates/hook/aftercarrier.tpl');
}	


public function getContent()
{
	if(Tools::isSubmit('savelivraisoncamersting')) 
	{
		$name = Tools::getValue('print');
		Configuration::updateValue('LIVRAISONCAMER_STR', $name);
	}
	$this->context->smarty->assign(array(
		'LIVRAISONCAMER_STR' => Configuration::get('LIVRAISONCAMER_STR')
	));
	return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
}

public function hookHeader()
{
    $this->context->controller->addCSS(array(
        $this->_path.'views/css/livraisoncamer.css'
    ));
}
		
}
