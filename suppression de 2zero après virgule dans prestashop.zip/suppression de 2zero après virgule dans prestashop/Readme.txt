
Comment supprimer les 2zero apr�s la virgule sur prestashop:

pour supprimer les 2zero apres la virgule sur les prix des article dans prestashop il faut aller � la racine de prestashop, entrer dans le repertoire 
-> translations/cldr/main--fr-FR--numbers
il faut remplacer le fichier: main--fr-FR--numbers par le fichier se trouvant dans le repertoire si.