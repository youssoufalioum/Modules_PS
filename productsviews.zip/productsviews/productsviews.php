<?php

if (!defined('_PS_VERSION_'))
	exit;

class Productsviews extends Module
{
	public function __construct()
	{
		$this->name = 'productsviews';
		$this->author = 'Youssouf Alioum';
		$this->version = '1.0.0';
		$this->bootstrap = true;
		parent::__construct();
		$this->displayName = $this->l('Vitrine 3D');
		$this->description = $this->l('Ce module permet de présenter 9 produits du jour en 3D');
		$this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}
	
	public function install()
	{
		return parent::install() && $this->registerHook('displayTopColumn') && $this->registerHook('displayHeader');
	}
	
	public function uninstall()
	{
		return parent::uninstall();
	}
	
	public function hookDisplayTopColumn()
	{
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT1' => Configuration::get('ADRESSE_IMAGE_PRODUIT1')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT1' => Configuration::get('LIEN_PRODUIT1')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT2' => Configuration::get('ADRESSE_IMAGE_PRODUIT2')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT2' => Configuration::get('LIEN_PRODUIT2')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT3' => Configuration::get('ADRESSE_IMAGE_PRODUIT3')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT3' => Configuration::get('LIEN_PRODUIT3')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT4' => Configuration::get('ADRESSE_IMAGE_PRODUIT4')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT4' => Configuration::get('LIEN_PRODUIT4')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT5' => Configuration::get('ADRESSE_IMAGE_PRODUIT5')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT5' => Configuration::get('LIEN_PRODUIT5')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT6' => Configuration::get('ADRESSE_IMAGE_PRODUIT6')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT6' => Configuration::get('LIEN_PRODUIT6')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT7' => Configuration::get('ADRESSE_IMAGE_PRODUIT7')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT7' => Configuration::get('LIEN_PRODUIT7')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT8' => Configuration::get('ADRESSE_IMAGE_PRODUIT8')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT8' => Configuration::get('LIEN_PRODUIT8')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT9' => Configuration::get('ADRESSE_IMAGE_PRODUIT9')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT9' => Configuration::get('LIEN_PRODUIT9')
		));
		
		return $this->display(__FILE__, 'views/templates/hook/home.tpl');
	}
	
	public function hookHeader()
	{
		$this->context->controller->addCSS(array(
		$this->_path.'views/css/productsviews.css'
		));
	}
	
	public function getContent()
	{
		if(Tools::isSubmit('btnsave'))
		{
			$adresse_1=Tools::getValue('print_a1');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT1', $adresse_1);
			$lien_1=Tools::getValue('print_l1');
			Configuration::updateValue('LIEN_PRODUIT1', $lien_1);
			
			$adresse_2=Tools::getValue('print_a2');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT2', $adresse_2);
			$lien_2=Tools::getValue('print_l2');
			Configuration::updateValue('LIEN_PRODUIT2', $lien_2);
			
			$adresse_3=Tools::getValue('print_a3');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT3', $adresse_3);
			$lien_3=Tools::getValue('print_l3');
			Configuration::updateValue('LIEN_PRODUIT3', $lien_3);
			
			$adresse_4=Tools::getValue('print_a4');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT4', $adresse_4);
			$lien_4=Tools::getValue('print_l4');
			Configuration::updateValue('LIEN_PRODUIT4', $lien_4);
			
			$adresse_5=Tools::getValue('print_a5');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT5', $adresse_5);
			$lien_5=Tools::getValue('print_l5');
			Configuration::updateValue('LIEN_PRODUIT5', $lien_5);
			
			$adresse_6=Tools::getValue('print_a6');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT6', $adresse_6);
			$lien_6=Tools::getValue('print_l6');
			Configuration::updateValue('LIEN_PRODUIT6', $lien_6);
			
			$adresse_7=Tools::getValue('print_a7');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT7', $adresse_7);
			$lien_7=Tools::getValue('print_l7');
			Configuration::updateValue('LIEN_PRODUIT7', $lien_7);
			
			$adresse_8=Tools::getValue('print_a8');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT8', $adresse_8);
			$lien_8=Tools::getValue('print_l8');
			Configuration::updateValue('LIEN_PRODUIT8', $lien_8);
			
			$adresse_9=Tools::getValue('print_a9');
			Configuration::updateValue('ADRESSE_IMAGE_PRODUIT9', $adresse_9);
			$lien_9=Tools::getValue('print_l9');
			Configuration::updateValue('LIEN_PRODUIT9', $lien_9);
			
			
		}
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT1' => Configuration::get('ADRESSE_IMAGE_PRODUIT1')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT1' => Configuration::get('LIEN_PRODUIT1')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT2' => Configuration::get('ADRESSE_IMAGE_PRODUIT2')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT2' => Configuration::get('LIEN_PRODUIT2')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT3' => Configuration::get('ADRESSE_IMAGE_PRODUIT3')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT3' => Configuration::get('LIEN_PRODUIT3')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT4' => Configuration::get('ADRESSE_IMAGE_PRODUIT4')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT4' => Configuration::get('LIEN_PRODUIT4')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT5' => Configuration::get('ADRESSE_IMAGE_PRODUIT5')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT5' => Configuration::get('LIEN_PRODUIT5')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT6' => Configuration::get('ADRESSE_IMAGE_PRODUIT6')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT6' => Configuration::get('LIEN_PRODUIT6')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT7' => Configuration::get('ADRESSE_IMAGE_PRODUIT7')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT7' => Configuration::get('LIEN_PRODUIT7')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT8' => Configuration::get('ADRESSE_IMAGE_PRODUIT8')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT8' => Configuration::get('LIEN_PRODUIT8')
		));
		
		$this->context->smarty->assign(array(
		'ADRESSE_IMAGE_PRODUIT9' => Configuration::get('ADRESSE_IMAGE_PRODUIT9')
		));
		$this->context->smarty->assign(array(
		'LIEN_PRODUIT9' => Configuration::get('LIEN_PRODUIT9')
		));
		return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
	}
}